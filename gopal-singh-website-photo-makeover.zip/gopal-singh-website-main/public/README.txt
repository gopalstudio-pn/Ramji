# Place your personal photos here:
# - gopal-hero.jpg (Hero background portrait)
# - gopal-about.jpg (About section portrait)
# - gopal-work-1.jpg (Selected work 01)
# - gopal-work-2.jpg (Selected work 02)
# - gopal-work-3.jpg (Selected work 03)
# - gopal-work-4.jpg (Selected work 04)
# - gopal-work-5.jpg (Selected work 05)
# - gopal-notes.jpg (Notes section visual anchor)
